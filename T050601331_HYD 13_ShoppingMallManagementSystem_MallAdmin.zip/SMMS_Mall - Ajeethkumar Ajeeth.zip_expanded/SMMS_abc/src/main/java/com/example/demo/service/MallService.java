package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Mall;

public interface MallService {
	
	public Mall saveMall(Mall customer);

	public List<Mall> fetchMallList();

	public Mall fetchMallById(Long customerId);

	public void deleteMallById(Long customerId);

	public Mall updateMall(Long customerId, Mall customer);



}
