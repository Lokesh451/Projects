package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Mall;
import com.example.demo.repository.MallRepo;


@Service
public class MallServiceImpl implements MallService {

	@Autowired
	private MallRepo mallRepo;
	
	@Override
	public Mall saveMall(Mall mall) {
		return mallRepo.save(mall);
		
	}
	@Override
    public List<Mall> fetchMallList() {
        return mallRepo.findAll();
    }

   @Override
   public Mall fetchMallById(Long mallId) {
	   return mallRepo.findById(mallId).get();
   }
	
   @Override
   public void deleteMallById(Long mallId) {
	   mallRepo.deleteById(mallId);
   }


   @Override
   public Mall updateMall(Long mallId, Mall mall) {
	   Mall mallDB = mallRepo.findById(mallId).get();

       if(Objects.nonNull(mall.getMallName()) &&
       !"".equalsIgnoreCase(mall.getMallName())) {
    	   mallDB.setMallName(mall.getMallName());
       }
       if(Objects.nonNull(mall.getLocation()) &&
    	       !"".equalsIgnoreCase(mall.getLocation())) {
    	    	   mallDB.setMallName(mall.getLocation());
    	}
       

       return mallRepo.save(mallDB);
   }
}
