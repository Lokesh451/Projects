package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Mall;
import com.example.demo.service.MallService;

@RestController
public class MallController {
	

	@Autowired
	private MallService mallService;
	
	@PostMapping("/mallvalue")
	public Mall saveMall(@RequestBody Mall mall) {
		return mallService.saveMall(mall);
	}
	
	@GetMapping("/mallvalue")
	public List<Mall> fetchMallList() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
        return mallService.fetchMallList();
    }
    
	@GetMapping("/mallvalue/{id}")
	public Mall fetchMallById(@PathVariable("id") Long mallId)
    {
		return mallService.fetchMallById(mallId);
    }

	@DeleteMapping("/mallvalue/{id}")
    public String deleteDepartmentById(@PathVariable("id") Long mallId) {
        mallService.deleteMallById(mallId);
        return "The mall is deleted. Renew if needed.";
    }
    
    @PutMapping("/mallvalue/{id}")
    public Mall updateMall(@PathVariable("id") Long mallId,
                                       @RequestBody Mall mall) {
        return mallService.updateMall(mallId,mall);
    }

}
