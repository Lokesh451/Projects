package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Mall {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	//private MallAdmin mallAdmin;
	private String mallName;
	private String location;
	//private List<Shop> shops;
	public Long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getMallName() {
		return mallName;
	}
	public void setMallName(String mallName) {
		this.mallName = mallName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Mall() {
		super();
	}
	public Mall(long id, String mallName, String location) {
		super();
		this.id = id;
		this.mallName = mallName;
		this.location = location;
	}
	@Override
	public String toString() {
		return "Mall [id=" + id + ", mallName=" + mallName + ", location=" + location + "]";
	}
	
}
